<template>
  <div class="area-page">
    <div class="background-video">
      <video 
        :src="babyVideo"
        autoplay
        preload="auto"
        playsinline
        muted
        webkit-playsinline
        loop
      ></video>
    </div>
    
    <div class="logo">
      <img :src="logo" alt="logo" class="logo-img" width="300" height="200">
    </div>
    
    <div class="back-button" @click="goBack">
      返回首页
    </div>
  </div>
</template>

<script>
export default {
  name: 'BabyPage',
  data() {
    return {
      logo: require('@/assets/svg/aito.svg'),
      babyVideo: require('@/assets/video/muying.mp4')
    }
  },
  methods: {
    goBack() {
      this.$router.push('/')
    }
  }
}
</script>

<style scoped>
@font-face {
  font-family: 'SourceHanSansCN-Regular';
  src: url('../assets/fonts/SourceHanSansCN-Regular.otf') format('opentype');
}

.area-page {
  height: 100vh;
  display: flex;
  flex-direction: column;
  color: white;
  position: relative;
}

.background-video {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
}

.background-video video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  background: #000;
}

.logo {
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 100;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgba(0, 0, 0, 0.5);
}

.back-button {
  position: absolute;
  bottom: 40px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(10px);
  border: 2px solid rgba(255, 255, 255, 0.3);
  /* border-radius: 50px; */
  padding: 15px 40px;
  font-size: 20px;
  font-weight: bold;
  color: white;
  cursor: pointer;
  transition: all 0.3s ease;
  font-family: 'SourceHanSansCN-Regular';
  z-index: 10;
}

.back-button:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: translateX(-50%) translateY(-3px);
  box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}
</style>
