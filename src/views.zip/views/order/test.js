





// 深度
const myfun_maxdeep=(erchashu)=>{

}
//层序
const myfun_loopsearch=(erchashu)=>{

}
const myfun=(towchar)=>{
  var listitem =1
  // towchar.reverse()
  for(let i=0;i<=towchar.length-1;i++){
           
  }
}

let erchashu= [3,9,20,null,null,15,7]
myfun(erchashu)
// console.log(myfun(erchashu))
//二叉树深度
// 输入: [3,9,20,null,null,15,7] 输出: 3