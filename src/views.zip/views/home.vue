<template>
  <div class="imgSwiper">

    
    <div class="logo">
      <img :src="logo" alt="logo" class="logo-img" width="300" height="200">
    </div>
    <div class="background-video">
      <video 
        :src="home"
        autoplay
        preload="auto"
        playsinline
        muted
        webkit-playsinline
        loop
      ></video>
    </div>
    <!-- 区域选择按钮 -->
     <!-- <div class="button_row">
        <div class="orderbut1" @click="handleAreaClick(currentArea)">
         {{ currentArea.name }}
        </div>
     </div> -->
     
     <!-- 底部区域选择栏 -->
     <div class="bottom-tab-bar">
       <div class="tab-container">
         <div 
           v-for="(area, index) in areas" 
           :key="area.id"
           class="tab-item"
           @click="goToArea(index)"
         >
           {{ area.name }}
         </div>
       </div>
     </div>
   
  </div>
</template>

<script>
import home from '../assets/home.mp4';
// import logo from '../assets/svg/aito.svg';

export default {
  data() {
    return {
      logo: require('@/assets/svg/aito.svg'), // 确保路径正确
      home: home, // 添加home视频引用
      areas: [
        { 
          id: 'bar', 
          name: '吧台', 
          route: '/order'
        },
        { 
          id: 'massage', 
          name: '按摩室', 
          route: '/massage'
        },
        { 
          id: 'restaurant', 
          name: '餐厅', 
          route: '/restaurant'
        },
        { 
          id: 'baby', 
          name: '母婴室', 
          route: '/baby'
        },
        { 
          id: 'parking', 
          name: '停车场', 
          route: '/parking'
        },
        { 
          id: 'children', 
          name: '儿童室', 
          route: '/children'
        }
      ],
      currentAreaIndex: 0,

    };
  },
  computed: {
    currentArea() {
      return this.areas[this.currentAreaIndex] || this.areas[0];
    }
  },
  components: {
  },
  mounted() {
    // 页面加载完成
    console.log('Home video path:', this.home);
    this.$nextTick(() => {
      const video = this.$el.querySelector('video');
      if (video) {
        console.log('Video element found:', video);
        video.addEventListener('loadeddata', () => {
          console.log('Video loaded successfully');
        });
        video.addEventListener('error', (e) => {
          console.error('Video error:', e);
        });
      }
    });
  },
  activated() {
    // 组件被激活时
  },
  deactivated() {
    // 组件被缓存时
  },
  methods: {

    handleAreaClick(area) {
      // 处理区域按钮点击事件
      console.log(`${area.name}按钮被点击`);
      // 跳转到对应区域页面
      this.$router.push(area.route);
    },
    
    goToArea(index) {
      // 直接跳转到对应区域页面
      const area = this.areas[index];
      if (area) {
        this.$router.push(area.route);
      }
    }
  },
  beforeDestroy() {
    // 组件销毁时清理资源
  }
};
</script>

<style scoped>
@font-face {
  font-family: 'SourceHanSansCN-Regular';
  src: url('../assets/fonts/SourceHanSansCN-Regular.otf') format('opentype');
}

.imgSwiper {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;
}

.button_row{
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
   /* border: 2px solid rgb(191, 191, 201);  */
  height: 100px;
  width:100%;
  align-items: center;
  z-index: 100;
  /* 脱离文档流，不占据位置 */
  position: absolute;
  /* 可选：设置位置，默认会在原来的位置 */
  top: 75vh;
  /* left: 0; */
}
.orderbut1 {
  width: 300px;
  height: 80px;
  /* background-color: #fff; */
  color: #ebebeb;
  font-size: 20px;
  border: 3px solid #ebebeb;
  font-weight: bold;
  /* border-radius: 10px; */
  margin: 0 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  font-size: 30px;
  font-family: 'SourceHanSansCN-Regular';
}
.orderbut {
  width: 300px;
  height: 100px;
  background-color: #ebebeb;
  color: #000;
  font-size: 20px;
  font-weight: bold;
  border-radius: 50px;
  margin: 0 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 30px;
  cursor: pointer;
    font-family: 'SourceHanSansCN-Regular';
}
.logo {
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 100;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgba(0, 0, 0, 0.5);
}



.background-video {
  width: 100%;
  height: 100vh;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
}

.background-video video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  background: #000;
  display: block;
}

.order-button {
  position: absolute;
  bottom: 60px;
  left: 50%;
  transform: translateX(-50%);
  background: #fff;
  color: #000;
  padding: 16px 40px;
  border-radius: 8px;
  font-size: 18px;
  font-weight: 500;
  cursor: pointer;
  z-index: 200;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  transition: all 0.3s ease;
  white-space: nowrap;
  text-align: center;
  min-width: 120px;
}

/* .order-button:hover {
  background: #f5f5f5;
  transform: translateX(-50%) translateY(-2px);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
}

.order-button:active {
  transform: translateX(-50%) translateY(0);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
} */

/* 底部选择栏样式 */
.bottom-tab-bar {
  position: absolute;
  bottom: 20px;
  left: 0;
  right: 0;
  background: transparent;
  padding: 0 20px;
  z-index: 150;
  pointer-events: none;
}

.tab-container {
  display: flex;
  gap: 15px;
  justify-content: flex-start;
  align-items: center;
  overflow-x: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;
  height: 100px;
  width: 100%;
  margin: 0 auto;
  pointer-events: auto;
  padding: 0 20px;
  box-sizing: border-box;
}

.tab-container::-webkit-scrollbar {
  display: none;
}

/* 添加平滑滚动 */
.tab-container {
  scroll-behavior: smooth;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .tab-container {
    max-width: 90%;
    gap: 10px;
  }
  
  .tab-item {
    font-size: 24px;
    padding: 10px 16px;
    min-width: 70px;
  }
  
  .tab-item.active {
    font-size: 28px;
  }
}

@media (max-width: 480px) {
  .tab-container {
    max-width: 95%;
    gap: 8px;
  }
  
  .tab-item {
    font-size: 20px;
    padding: 8px 12px;
    min-width: 60px;
  }
  
  .tab-item.active {
    font-size: 24px;
  }
}

.tab-item {
  flex: 0 0 auto;
  height: 60px;  
  align-items: center;
  justify-content: center;
  display: flex;
  color: #fff;
  /* border-radius: 8px; */
  cursor: pointer;
  border: 3px solid #fff;
  transition: all 0.3s ease;
  font-family: 'SourceHanSansCN-Regular';
  font-size: 28px;
  font-weight: 400;
  white-space: nowrap;
  outline: none;
  backdrop-filter: blur(5px);
  /* min-width: fit-content; */
  /* box-sizing: border-box; */
}

.tab-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 255, 255, 0.3);
}

.tab-item.active {
  border: 3px solid #fff;
  color: #ffffff;
  font-weight: 600;
  font-size: 32px;
  box-shadow: 0 4px 15px rgba(255, 255, 255, 0.4);
}
</style>
